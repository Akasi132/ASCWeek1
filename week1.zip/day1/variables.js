let num1= 100;
let num2= .54;

let string1="ASCrawr";
let string2="happy gng"

let bool1=true;
let bool2=false;

console.log("1st variable:",num1);
console.log("2nd variable:",num2);
console.log("3rd variable:",string1);
console.log("4th variable:",string2);
console.log("5th variable:",bool1);
console.log("6th variable:",bool2);
