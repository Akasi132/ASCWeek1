//Part 1 Answers:
// 1)no output
// 2)The value of x is 1
// 3)All Star Code!
// 4)50 ABCdef 2030
// 5)Sum: 13
// 6)Sum: 8
// 7)8
// Part 2

// We're going to earn a profit by reselling tickets
// We bought some tickets to see Billie Eilish
// 4 regular tickets for $45 each and 2 front row tickets for $75 each
let cost=45 * 4 + 75 * 2;

console.log('Cost:', (cost));


// We're reselling the tickets for 50% above the original price
console.log('Selling price:', (cost) * 1.5);


// But StubHub, the online ticket selling platform, charges a 20% seller fee
console.log('Seller fee:', (cost) * 1.5 * 0.2);


// Our total profit:
console.log('Profit:', (cost) * 1.5 - (cost) - (cost) * 1.5 * 0.2);


//Y=2
//