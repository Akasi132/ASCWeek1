let answer;
let num1="3";
let num2="5";
let num3=10;
let num4=4;

answer=num1+num2;
console.log(num1, "+", num2, "=",answer);

answer=num3%num4;
console.log(num3, "+", num4, "=",answer);

