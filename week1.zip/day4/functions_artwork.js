//Part 1-----------------------------------------------------------
// function letterR(){
//     console.log("#####")
//     console.log("#   #")
//     console.log("# # #")
//     console.log("#  #")
//     console.log("#   #")
//     console.log()
// }

// function letterA(){
//     console.log("  # ")
//     console.log(" # #")
//     console.log(" ###")
//     console.log("#   #")
//     console.log()
// }
// function letterD(){
//     console.log("#####")
//     console.log("#    #")
//     console.log("#    #")
//     console.log("#####")
//     console.log();
// }

// letterR();
// letterA();
// letterD();
// letterA();
// letterR();

//Part 2-------------------------------------------------------------------------
// function Head(){
//     console.log("############")
//     console.log("##        ##")
//     console.log("##  D  D  ##")
//     console.log("###  U   ### ")
//     console.log("#############")
// }
// function body(){
//     console.log("    ##")
//     console.log("    ##")
//     console.log("    ##")
//     console.log("    ##")
//     console.log("   # #")
//     console.log("  #  #")
//     console.log("  #   #")
// }
// Head();
// body();