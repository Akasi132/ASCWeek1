//Part 1a--------------------
// let count=100;
// while(count>-1){
//     console.log(count);
//     count--;
// }

//Part 1b-----------------------
// let count=process.argv[2];
// while(count>-1){
//     console.log(count);
//     count--;
// }

//Part 2------------------------------------
//Question 1: 3 times
//Question 2: Infinite loop
//Question 3: 5 times
//Question 4: 2 times
//Question 5:
// let num = 0;
// while (num < 10) {
//    console.log("Little Donald Drumpf");
//    num++;
// }

//Part 3a----------------------
// let bool=true;
// while(bool){
//     num1=Math.floor(Math.random()*11);
//     num2=Math.floor(Math.random()*11);
//     console.log("1st random number:",num1,"2nd random number:",num2);
//     if (num1==num2){
//         console.log("Same random number! End Loop");
//         bool=false;
//     }
// }

//Part 3b----------------------------
// let bool=true;
// let count=1;
// while(bool){
//     num1=Math.floor(Math.random()*11);
//     num2=Math.floor(Math.random()*11);
//     console.log("Try","#"+count,"1st random number:",num1,"2nd random number:",num2);
//     if (num1==num2){
//         console.log("Same random number on try","#"+count+"!","End Loop");
//         bool=false;
//     }
//     count+=1;
// }

//Extra Credit----------------------------------
// let userInp=Number(process.argv[2]);
// let string="";
// bool=true;
// while (bool){
//     remainder=userInp%2;
//     string=String(remainder)+string;
//     userInp=Math.floor(userInp/2);
//     console.log(string,userInp);
//     if ((Math.floor(userInp/2))==0){
//         remainder=userInp%2;
//         string=String(remainder)+string;
//         bool=false;
//     }
// }
// console.log(string);