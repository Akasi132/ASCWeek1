//Part 1-----------------

// function combineStrings(str1,str2){
//     let nwString=str1+str2;
//     return nwString;
// }
// let s1=combineStrings("ABC","DEF");
// let s2=combineStrings("3","4");
// console.log(s1,s2);

//Part 2---------------
//Program #1:["a","b","c"], [e1,e2,e3]
//Proragm#2:1, 5, 0
//Program #3:2.5, 15, 5

//Part 3-----------------
// function checkAnswer(num1,num2,operator,answer){
//     if (operator=="+"){
//         if (num1+num2==answer){
//             console.log(true);
//         }
//         else{
//             console.log(false);
//         }
//     }
//     else if(operator=="-"){
//         if(num1-num2==answer){
//             console.log(true);
//         }
//         else{
//             console.log(false);
//         }
//     }
//     else{
//         console.log("please input a proper operator!")
//     }
// }
// checkAnswer(1,2,"+",5)

//Part 4---------------------------
// function oddNumberCatcher(list){
//     let bool=true;
//     for(let i=0;i<list.length;i++){
//         if (list[i]%2!=0){
//             bool=false;
//             return i;
//         }
//     }
//     if (bool){
//         return -1;
//     }
// }

// let i2= oddNumberCatcher([2,4,6,78])
// console.log(i2);

//Extra Credit--------------------------------
// function larger(num1,num2){
//     if (num1>=num2){
//         return num1;
//     }
//     else{
//         return num2;
//     }
// }
// function largest(num1,num2,num3,num4){
//     return larger(larger(num1,num2),larger(num3,num4));
    
// }

// let x=largest(5,3,10,3)
// console.log(x);