function pokedex(name,type,genNum){
    console.log(name,"is a Gen",genNum,type+"-type Pokemon");

}
pokedex("Squirtle","Water","3");