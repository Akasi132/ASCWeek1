//Part 1-------------------------------
// function evenOrOdd(number){
//     if (number%2==0){
//         console.log(`${number} is a even number`)
//     }
//     else{
//         console.log(`${number} is a odd number`)
//     }
// }

// evenOrOdd(7);
// evenOrOdd(6872);
// evenOrOdd(-5);

//Part 2------------------------------------------
// function divisor(number,divisor){
//     if(number%divisor==0){
//         console.log(`${number} is divisible by ${divisor}`)
//     }
//     else{
//         console.log(`${number} is not divisible by ${divisor}`)
//     }
// }
// divisor(9,3);
// divisor(27,5);

//Part 3---------------------------------------------------
// function distanceCalculator(name1,x1,y1,name2,x2,y2){
//     let dist=Math.sqrt(((x2-x1)**2)+((y2-y1)**2))
//     console.log(`${name1} is ${dist} meters away from ${name2}`)
// }
// distanceCalculator("Michael",3.28,2.26,"Anthony",3.92,3);

//Part 4------------------------------------------------------
// function arrayHandler(array){
//     for (let i=0;i<array.length;i++){
//         if (typeof(array[i])=="string"){
//             console.log(array[i])
//         }
//     }
// }

// arrayHandler([1,"a","b",4,false,"true"])

//Extra credit----------------------------------------

// function primeOrNot(number){
//     let bool=true;
//     for(let i=2;i<number;i++){
//         if (number%i==0){
//             console.log(`${number} is divisible by ${i}`)
//             console.log(`${number} is not a prime number`)
//             bool=false;
//             break;
//         }
//         else{
//             console.log(`${number} is not divisible by ${i}`)
//         }
//     }
//     if (bool){
//         console.log(`${number} is a prime number`)
//     }
// }

// primeOrNot(13);