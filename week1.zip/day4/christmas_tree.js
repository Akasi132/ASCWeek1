// let user_guess=process.argv[2];
// let string=""
// for (let i=0;i<Number(user_guess);i++){
//     string=string+"*";
//     console.log(string);

// }

function drawTree() {
    let string2="";
    let string="";
    let finalstring="";
    for (let i=0;i<10;i++){
        string2="  *"+string2;
        string=string+"*";
        finalstring=string2+string;
        console.log(finalstring);
    }
}

drawTree();
