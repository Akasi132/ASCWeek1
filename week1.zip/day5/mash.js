function mash(){
    
    if (process.argv[2]==undefined || process.argv[3]==undefined){
        console.log("please input something!");
    }
    else{
    let userInp=process.argv[2];
    let home=getHome(userInp);
    let pet1=getPet();
    let college1=getCollege();
    let occupation1=getOccupation();
    console.log("You will live in a " + home +", travel to "+getTravelCount()+ " countries, have a pet "+pet1+", and graduate from "+college1+" as a "+occupation1+"!");
    if(home=="Garbage Truck" || pet1=="snail" ||college1=="Las Positas" || occupation1=="Cleaner"){
        console.log("You got a little unlucky :(")
    }
    else{
        console.log("You got pretty lucky :)")
    }
    }
}

mash();
function randNumGenerator(number){
    randInt=Math.floor(Math.random()*number);
    return randInt;
}


function getHome(newOption){
    let places=["Mansion","Castle","Shack","House","Garbage Truck"]
    places.push(newOption);
    return places[randNumGenerator(places.length)];
}
function getTravelCount(){
    return randNumGenerator(101);
}
function getPet(){
    let userInp2=process.argv[3];
    let pets=["dog", "cat", "fish", "bird", "hamster","snail"];
    if (randNumGenerator(2)==0){
        return userInp2;
    }
    else{
        return pets[randNumGenerator(pets.length)]
    }
}
function getCollege(){
    let colleges=["Harvard University", "Stanford University", "Massachusetts Institute of Technology", "University of California, Berkeley", "University of Oxford","Las Positas"]
    return colleges[randNumGenerator(colleges.length)];
}

function  getOccupation(){
    let occupation=["Doctor", "Engineer", "Teacher", "Lawyer", "Artist","Cleaner"];
    return occupation[randNumGenerator(occupation.length)];
}