//Part 1---------------------------------
// let numInt=Math.floor((Math.random()*11));
// let numInt2=Math.floor((Math.random()*11));
// answer=numInt+numInt2;
// console.log("Random number #1",numInt)
// console.log("Random number #2:",numInt2);

// console.log("Sum:",numInt,"+",numInt2,"=",answer);

//Part 2----------------------------------------------
// let days = ['Friday', 'Monday', 'Today', 'Yesterday', 'Your Birthday', 'Never', 'Sundae'];


// let reactions = ['Yay!', 'Ahhhhh!!!', 'Wu wi wa wa', 'Guli Guli', 'Ka chow'];
// let randDay=Math.floor((Math.random()*days.length));
// let randReaction=Math.floor((Math.random()*reactions.length));
// console.log("Your Lucky Day:",days[randDay]);
// console.log(reactions[randReaction]);

//Extra Credit---------------------------------------------
// let numInt=Math.floor((Math.random()*18)+37);
// console.log(numInt);