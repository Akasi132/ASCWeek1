let randDecimal = Math.random();
let random=randDecimal*5;
let randInt=Math.floor(random);
console.log("randDecimal:", randInt);