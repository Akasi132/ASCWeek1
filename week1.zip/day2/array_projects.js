//Part 1---------------------------------------------------------
//Program A: B, D, Index out of range
//Program B: Mon, Sun, 7, Index out of range, Sun
//Program C: ["Do","Re","Mi","Fa","So"], ["Do","Re"], []

//Part 2----------------------------------------------------------
// let scores=[85, 93, 65, 65, 92, 81, 93];
// let average=0;
// for (let i=0;i<scores.length;i++){
//     average+=scores[i];
// }
// console.log(average/scores.length);

//Part 3-------------------------------------------------------------

//Transformation 1:
// let char=['a','b','c','d'];
// console.log("Before:",char);
// char.reverse();
// console.log("After:",char);

//Transformation 2:
// let char=['a','b','c','d'];
// console.log("Before:",char);
// char.push(1,2);
// console.log("After:",char);

//Transformation 3:
// let char=['a','b','c','d'];
// console.log("Before:",char);
// char.pop();
// console.log("After:",char);

//Transformation 4:
// let char=['a','b','c','d'];
// console.log("Before:",char);
// let a=char[1];
// char[1]=char[2];
// char[2]=a;
// console.log("After:",char);

//Transformation 5:
// let char=['a','b','c','d'];
// console.log("Before:",char);
// char.pop();
// char.push('e','f');
// char.reverse();
// console.log("After:",char);

//EXTRA CREDIT--------------------------------------------------------
let myArray = ['Hi', 90, '90', [1, 2, 3, 4], ':p'];
console.log(myArray[3]);
console.log(myArray[3][1]);