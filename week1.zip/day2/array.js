//PART 1----------------------------------------------------------
// let pokemon=["Venasuar","Pikachu","Ivy","Charizard","Eevee"];
// for (let i=0;i<pokemon.length;i++){
//     console.log(pokemon[i]);
// }

//Part 2----------------------------------------------------------------
// let mixArray=["America",7.4,true,[0,1,2]];

// mixArray[2]="Misplaceddd";
// mixArray.push("helooo")

// console.log(mixArray);

// mixArray.pop();
// mixArray.reverse();
// console.log(mixArray);
// console.log('Length of mixArray:', mixArray.length);

//Part 3---------------------------------------------------------------------

let numArray=[5,4,6,3,2,1];
numArray.sort();
numArray.length=0;
console.log(numArray);
