//Program 1)Undefined

// let a=process.argv[3];
// console.log(typeof(a));

//Program 2)PIKACHU

//Program 3)BOOOSPOKKY,UNDEFINED

//Program 4)string, udnefined

//Program 5)twothree


//PROJECT PART 2-----------------------------------------
// let Name=process.argv[2];
// let Age=process.argv[3];
// let Gender=process.argv[4];
// let DOB=process.argv[5];
// let Phone_num=process.argv[6];

// console.log("Name:",Name);
// console.log("Age:",Age);
// console.log("Gender:",Gender);
// console.log("DOB:",DOB);
// console.log("Phone No.:",Phone_num);

//EXTRA CREDIT--------------------------------------------------
// let num1=Number(process.argv[2]);
// let num2=Number(process.argv[3]);
// result=num1+num2;

// console.log(num1,"+",num2,"=",result);