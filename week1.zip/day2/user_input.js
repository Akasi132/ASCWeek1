let first_input=process.argv[2];
let second_input=process.argv[3];
let third_input=process.argv[4];
console.log("Input A:",first_input);
console.log("Input B:",second_input);
console.log("Input C:",third_input);

console.log();
console.log("Data Type A:",typeof(first_input));
console.log("Data Type B:",typeof(second_input));
console.log("Data Type C:",typeof(third_input));
