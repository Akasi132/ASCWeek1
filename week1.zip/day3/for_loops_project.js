//Part 1a------------------------------------
// for (let i=100;i>=0;i--){
//     console.log(i);
// }


//part 1b------------------------------------------
// let user_inp=process.argv[2];
// for (let i=Number(user_inp);i>=0;i--){
//     console.log(i);
// }

//Part 2------------------------------------------------
// let student=["suhaan","Carlos","Bayan","Shifatul","Samuel"]
// for (let i=0;i<student.length;i++){
//     console.log(`ASC Tech Visionaries-${student[i]}`)
// }

//Part 3------------------------------------------------
//Question 1:cute puppies
//Question 3: The functionality is to incremebet num1 and num2.

//Extra Credit------------------------------------------------
// let bigArray = [
//     'S', 'Z', 'A', 'H', 'G', 'B', 'Y', 'I', 'A', 'N', 'T', 'V', 'C', 'Q', 'C', 'P',
//     'D', 'Q', 'Q', 'K', 'T', 'N', 'J', 'V', 'U', 'Q', 'Q', 'C', 'V', 'P', 'A', 'G',
//     'Z', 'A', 'R', 'U', 'A', 'P', 'M', 'B', 'R', 'A', 'R', 'O', 'F', 'I', 'G', 'F',
//     'O', 'L', 'B', 'R', 'V', 'Y', 'P', 'J', 'H', 'O', 'S', 'A', 'A', 'O', 'F', 'T',
//     'E', 'S', 'J', 'W', 'T', 'B', 'R', 'R', 'Y', 'B', 'O', 'A', 'O', 'S', 'Y', 'U',
//     'W', 'E', 'Q', 'M', 'O', 'F', 'H', 'W', 'K', 'G', 'Y', 'F', 'A', 'W', 'S', 'U',
//     'O', 'T', 'C', 'D', 'B', 'Z', 'A', 'H', 'G', 'B', 'Y', 'I', 'A', 'N', 'T', 'V',
//     'C', 'Q', 'C', 'P', 'D', 'Q', 'Q', 'K', 'E', 'N', 'J', 'V', 'U', 'Q', 'Q', 'C',
//     'V', 'P', 'A', 'G', 'Z', 'A', 'R', 'U', 'A', 'P', 'M', 'B', 'R', 'A', 'R', 'O',
//     'F', 'I', 'G', 'F', 'O', 'L', 'B', 'R', 'V', 'Y', 'P', 'J', 'H', 'O', 'S', 'A',
//     'R', 'O', 'F', 'T', 'E', 'S', 'J', 'W', 'T', 'B', 'R', 'R', 'Y', 'B', 'O', 'A',
//     'O', 'S', 'Y', 'U', 'Y', 'E', 'Q', 'M', 'O', 'F', 'H', 'W', 'K', 'G', 'Y', 'F',
//     'A', 'W', 'S', 'U', 'O', 'T', 'C', 'D'
//  ];
// string=""
// for (let i=1;i<bigArray.length;i++){
//     if (i%20==0){
//        console.log(bigArray[i]);
//     }
// }
// console.log(string);