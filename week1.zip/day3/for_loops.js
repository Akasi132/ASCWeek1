
let pokemon = ['Bulbasaur', 'Charmander', 'Squirtle', 'Pikachu', 'Mewtwo',"Blaziken","Ivasaur"];


for (let i = 0; i < pokemon.length; i++) {
    console.log(i,pokemon[i]);
    if (pokemon[i]=="Pikachu"){
        console.log("Terminating for loop...");
        break;
    }
 }
 