let user_guess=process.argv[2];
let answer=5;
let score=0;

if (user_guess==answer) {
    console.log("Correct Guess!");
 }
else if(user_guess<answer){
    console.log("Too low...");
}
else{
    console.log("Too high...")
}