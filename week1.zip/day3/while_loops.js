let count=0;
while (count!=10){
    console.log("Google");
    ++count;
}