//Trace outputs--------------------------

//Program1: @#
//Program2:@
//Program3:@
//Program4:0
//program5:true blocks are executed

//Part 2--------------------------------------
// let numRand=Math.random();
// let answer=Math.floor(numRand*101);
// let user_guess=process.argv[2];
// if (answer==user_guess){
//     console.log("You are right!");
// }
// else if (answer<user_guess){
//     console.log("TOO HIGH");
// }
// else{
//     console.log("TOO LOW");
// }
// console.log("This it the right answer:",answer);

//Part 3-------------------------------------------
// let user_guess=process.argv[2];
// let score=0;
// console.log("Initial score:",score);
// console.log();

// if (user_guess=="A" || user_guess=="B"){
//     score-=1;
//     console.log("Wrong answer :(");
// }
// else if (user_guess=="C"){
//     score+=5;
//     console.log("RIGHT ANSWER! WOHOO!!!");
// }
// else if(user_guess=="D"){
//     score-=50;
//     console.log("Bad bad bad...");
// }
// else if(user_guess=="I.KNOW.THE.SECRET"){
//     score+=1000000
//     console.log("Welcome to NIRVANA");

// }
// else if(user_guess==undefined){
//     console.log("Empty response.. Bad user");
// }
// else{
//     console.log("Invalid response");
// }

// console.log("Final Score:",score);

//EXTRA CREDIT----------------------------------------
// let species=process.argv[2];
// let name=process.argv[3];

// if (species=='Pokemon'){
//     if (name=="Pikachu"){
//         console.log("Hello Pikachu, you're an electric mouse!");
//     }
//     else if(name=="Charmander"){
//         console.log("Hello Charmander, your final evolution is cool beans!");
//     }
//     else{
//         console.log("Hello",name+",","we do not have your Pokemon data yet...");
//     }
// }
// else if(species=="human"){
//     console.log("Hello",name,"you're a human, not a Pokemon :(");
// }
// else{
//     console.log("Unknown species... INTRUDER INTRUDER!");
// }
