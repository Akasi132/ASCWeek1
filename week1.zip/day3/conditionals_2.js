let hello;
console.log(typeof(hello));
if (!hello){
    console.log("Not defined");
}

if (1<2 || "b"=="B"){
    console.log("True");
}